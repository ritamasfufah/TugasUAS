package com.ritamasfufah.uas;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText editNama, editNohp, editAlamat;
    Button btnHitung;
    TextView tvHasil;
    Spinner spinnerPilihan;
    String[] pilihDaftar = {"Mobile", "Web", "Dekstop"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editNama = findViewById(R.id.editNama);
        editNohp = findViewById(R.id.editNohp);
        editAlamat = findViewById(R.id.editAlamat);
        btnHitung = findViewById(R.id.btn_daftar);
        tvHasil = findViewById(R.id.tv_hasil);
        spinnerPilihan = findViewById(R.id.spinner_pilihan);

        btnHitung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (spinnerPilihan.getSelectedItem().toString().equals(pilihDaftar[0])) {
                    String hasil = "syarat bawa smartphone";
                   tvHasil.setText(hasil.toString());
                    //ctrl+alt+m
                }else if (spinnerPilihan.getSelectedItem().toString().equals(pilihDaftar[1])) {
                    String hasil = "syarat bawa laptop";
                    tvHasil.setText(hasil.toString());
                }else if (spinnerPilihan.getSelectedItem().toString().equals(pilihDaftar[2])) {
                    String hasil = "Syarat Bawa Laptop plus ada Netbeans";
                    tvHasil.setText(hasil.toString());
                }
            }
        });
        ArrayAdapter adapter = new ArrayAdapter(MainActivity.this, android.R.layout.simple_spinner_dropdown_item, pilihDaftar);
        spinnerPilihan.setAdapter(adapter);


    }


}
